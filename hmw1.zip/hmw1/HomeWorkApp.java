public class HomeWorkApp {
    public static void main(String[] args)
    {
        chcp 1251
        printThreeWords();
        checkSumSign();
        printColor();
    }
    public static void printThreeWords()
    {
        System.out.println(
                "Orange\n" +
                "Banana\n" +
                "Apple");
    }
    public static void checkSumSign()
    {
        int a,b;
        a=2;
        b=3;
        if(a+b>=0)
        {
            System.out.println("Сумма положительная");
        }
        else {
            System.out.println("Сумма отрицательная");

        }
    }
    public static void printColor()
    {
        int value=666;
        if(value<=0)
        {
            System.out.println("красный");
        }
        else if (value<0 && value>=100)
        {
            System.out.println("желтый");
        }
         else if(value>100)
        {
            System.out.println("зеленый");
        }
    }
}
